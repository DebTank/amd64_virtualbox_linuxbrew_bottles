void MVM_spesh_osr_poll_for_result(MVMThreadContext *tc);
