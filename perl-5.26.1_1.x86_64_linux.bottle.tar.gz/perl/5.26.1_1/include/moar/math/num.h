MVMint64 MVM_num_isnanorinf(MVMThreadContext *tc, MVMnum64 n);
MVMnum64 MVM_num_posinf(MVMThreadContext *tc);
MVMnum64 MVM_num_neginf(MVMThreadContext *tc);
MVMnum64 MVM_num_nan(MVMThreadContext *tc);
