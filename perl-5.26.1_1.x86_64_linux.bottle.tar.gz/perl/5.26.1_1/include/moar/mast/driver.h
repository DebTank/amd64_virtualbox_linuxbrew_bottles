void MVM_mast_to_cu(MVMThreadContext *tc, MVMObject *mast, MVMObject *types, MVMRegister *res);
void MVM_mast_to_file(MVMThreadContext *tc, MVMObject *mast, MVMObject *types, MVMString *filename);
