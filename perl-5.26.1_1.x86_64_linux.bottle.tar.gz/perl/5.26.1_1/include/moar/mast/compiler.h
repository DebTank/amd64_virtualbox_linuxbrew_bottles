char * MVM_mast_compile(MVMThreadContext *tc, MVMObject *node, MASTNodeTypes *types,
    unsigned int *size);
